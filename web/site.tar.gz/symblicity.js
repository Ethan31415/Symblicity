export class SymblicityVM {
  constructor(options = {}) {
    this.onByte = options.onByte || (() => {});
    this.onNumber = options.onNumber || (() => {});
    this.onAudio = options.onAudio || (() => {});
    this.onState = options.onState || (() => {});
    this.maxStack = options.maxStack || 4096;
    this.audio = options.audio || null;
    this.reset('');
  }

  static preprocess(source) {
    let out = '';
    for (let i = 0; i < source.length; i++) {
      const c = source[i];
      if (c === '\t') {
        while (i + 1 < source.length && source[i + 1] !== '\n' && source[i + 1] !== '\r') i++;
        continue;
      }
      if (c === '\n' || c === '\r' || c === '\f' || c === '\v') continue;
      out += c;
    }
    return out;
  }

  reset(source = this.originalSource || '') {
    this.originalSource = source;
    this.source = SymblicityVM.preprocess(source);
    this.n = this.source.length;
    this.r = new Uint8Array(5);
    this.mw = new Uint8Array(256);
    this.my = new Uint8Array(256);
    this.aw = 0;
    this.ay = 0;
    this.stack = new Uint8Array(this.maxStack);
    this.head = 0;
    this.sp = 0;
    this.bottom = false;
    this.bank = 0;
    this.d = 1;
    this.pc = 0;
    this.ret = -1;
    this.rs = '';
    this.input = [];
    this.stopped = false;
    this.error = null;
    this.steps = 0;
    this.waiting = null;
    this.onState(this.state());
  }

  get aIndex() { return this.bank === 0 ? 0 : 3; }
  get bIndex() { return this.bank === 0 ? 1 : 4; }
  get A() { return this.r[this.aIndex]; }
  set A(v) { this.r[this.aIndex] = v & 255; }
  get B() { return this.r[this.bIndex]; }
  set B(v) { this.r[this.bIndex] = v & 255; }

  state() {
    return {
      registers: Array.from(this.r),
      A: this.aIndex,
      B: this.bIndex,
      pc: this.pc,
      direction: this.d,
      stackSize: this.sp,
      bank: this.bank,
      steps: this.steps,
      stopped: this.stopped,
      waiting: this.waiting,
      error: this.error,
      sourceLength: this.n,
      aw: this.aw,
      ay: this.ay,
    };
  }

  queueBytes(bytes) {
    for (const b of bytes) this.input.push(b & 255);
    this.waiting = null;
  }

  queueText(text) {
    const bytes = new TextEncoder().encode(text);
    this.queueBytes(bytes);
  }

  findc(p, d, c) {
    for (p += d; p >= 0 && p < this.n; p += d) if (this.source[p] === c) return p;
    return -1;
  }

  letter(p, d, c) {
    const code = c.charCodeAt(0);
    const q = code >= 97 && code <= 122 ? c.toUpperCase() : c.toLowerCase();
    return this.findc(p, d, q);
  }

  pair(p, d, same, other) {
    let depth = 1;
    for (p += d; p >= 0 && p < this.n; p += d) {
      if (this.source[p] === same) depth++;
      else if (this.source[p] === other && --depth === 0) return p;
    }
    return -1;
  }

  leaveLoop(p, d) {
    let depth = 0;
    let q;
    if (d > 0) {
      for (let i = p - 1; i >= 0; i--) {
        if (this.source[i] === ']') depth++;
        else if (this.source[i] === '[') {
          if (depth) depth--;
          else if ((q = this.pair(i, 1, '[', ']')) > p) return q + 1;
        }
      }
    } else {
      for (let i = p + 1; i < this.n; i++) {
        if (this.source[i] === '[') depth++;
        else if (this.source[i] === ']') {
          if (depth) depth--;
          else if ((q = this.pair(i, -1, ']', '[')) >= 0 && q < p) return q - 1;
        }
      }
    }
    return p + d;
  }

  memoryLetter(c) {
    return 'wWxXyYzZ'.includes(c);
  }

  audioLetter(c) {
    if (!this.audio || !this.audio.count) return false;
    if ('uUvV'.includes(c)) return true;
    return !!this.audio.dual && 'tT'.includes(c);
  }

  reservedLetter(c) {
    return this.memoryLetter(c) || this.audioLetter(c);
  }

  readNumberFromQueue() {
    let end = -1;
    for (let i = 0; i < this.input.length; i++) {
      const b = this.input[i];
      if (b === 9 || b === 10 || b === 13 || b === 32) { end = i; break; }
    }
    if (end < 0) return null;
    const token = String.fromCharCode(...this.input.splice(0, end));
    this.input.shift();
    const v = Number.parseInt(token, 10);
    return Number.isFinite(v) ? (v & 255) : 0;
  }

  fail(message) {
    this.error = message;
    this.stopped = true;
    this.waiting = null;
    this.onState(this.state());
    return { status: 'error', message };
  }

  step() {
    if (this.stopped) return { status: this.error ? 'error' : 'stopped' };
    if (this.pc < 0 || this.pc >= this.n) {
      this.stopped = true;
      this.waiting = null;
      this.onState(this.state());
      return { status: 'stopped' };
    }

    const o = this.source[this.pc];
    this.steps++;

    if (o === ' ') {
      this.pc += 2 * this.d;
      return { status: 'ok' };
    }

    if (/^[A-Za-z]$/.test(o) && !this.reservedLetter(o)) {
      const q = this.letter(this.pc, this.d, o);
      this.pc = q < 0 ? this.pc + this.d : q;
      return { status: 'ok' };
    }

    let q;
    switch (o) {
      case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7':
        this.A = this.A + (1 << (o.charCodeAt(0) - 48));
        break;
      case '8': this.A = this.A - 1; break;
      case '9': this.A = this.A - 2; break;

      case '+': this.r[2] = (this.A + this.B) & 255; break;
      case '-': this.r[2] = (this.A - this.B) & 255; break;
      case '*': this.r[2] = (this.A * this.B) & 255; break;
      case '/': this.r[2] = this.B ? Math.floor(this.A / this.B) & 255 : 0; break;
      case '%': this.r[2] = this.B ? (this.A % this.B) & 255 : 0; break;
      case '^': this.r[2] = (this.A ^ this.B) & 255; break;
      case '|': this.r[2] = (this.A | this.B) & 255; break;
      case '&': this.r[2] = (this.A & this.B) & 255; break;

      case '=': if (this.A === this.B) this.pc += this.d; break;
      case '<': if (this.A < this.B) this.pc += this.d; break;
      case '>': if (this.A > this.B) this.pc += this.d; break;
      case '!': if (this.A !== this.B) this.pc += this.d; break;
      case '?': if (this.r[2] === 0) this.pc += this.d; break;
      case ':': {
        const t = this.A; this.A = this.B; this.B = t;
        break;
      }
      case ';': {
        const t = this.B; this.B = this.r[2]; this.r[2] = t;
        break;
      }
      case '\\': this.bank ^= 1; break;

      case '@':
        if (this.sp === this.maxStack) return this.fail('stack overflow');
        if (this.bottom) {
          this.head = (this.head - 1) & (this.maxStack - 1);
          this.stack[this.head] = this.A;
        } else {
          this.stack[(this.head + this.sp) & (this.maxStack - 1)] = this.A;
        }
        this.sp++;
        break;
      case '$':
        if (!this.sp) this.A = 0;
        else if (this.bottom) {
          this.A = this.stack[this.head];
          this.head = (this.head + 1) & (this.maxStack - 1);
          this.sp--;
        } else {
          this.sp--;
          this.A = this.stack[(this.head + this.sp) & (this.maxStack - 1)];
        }
        break;
      case '_': this.bottom = !this.bottom; break;

      case "'":
        if (!this.input.length) {
          this.waiting = 'char';
          return { status: 'wait_char' };
        }
        this.A = this.input.shift();
        this.waiting = null;
        break;
      case '"': this.onByte(this.A); break;
      case '.': {
        const v = this.readNumberFromQueue();
        if (v === null) {
          this.waiting = 'number';
          return { status: 'wait_number' };
        }
        this.A = v;
        this.waiting = null;
        break;
      }
      case ',': this.onNumber(this.A); break;

      case 'w': this.aw = this.A; break;
      case 'W': this.A = this.aw; break;
      case 'x': this.mw[this.aw] = this.A; break;
      case 'X': this.A = this.mw[this.aw]; break;
      case 'y': this.ay = this.A; break;
      case 'Y': this.A = this.ay; break;
      case 'z': this.my[this.ay] = this.A; break;
      case 'Z': this.A = this.my[this.ay]; break;

      case 'U':
        if (this.audio?.count) {
          this.audio.selected = (this.audio.selected + 1) % this.audio.count;
          this.onAudio({ type: 'select', selected: this.audio.selected });
        }
        break;
      case 'u':
        if (this.audio?.count) {
          this.audio.selected = (this.audio.selected + this.audio.count - 1) % this.audio.count;
          this.onAudio({ type: 'select', selected: this.audio.selected });
        }
        break;
      case 'V':
        if (this.audio?.count) this.onAudio({ type: 'play', channel: 0, selected: this.audio.selected });
        break;
      case 'v':
        if (this.audio?.count) this.onAudio({ type: 'stop', channel: 0 });
        break;
      case 'T':
        if (this.audio?.count && this.audio.dual) this.onAudio({ type: 'play', channel: 1, selected: this.audio.selected });
        break;
      case 't':
        if (this.audio?.count && this.audio.dual) this.onAudio({ type: 'stop', channel: 1 });
        break;

      case '#':
        this.pc += (this.A + 1) * this.d;
        return { status: 'ok' };
      case '{':
        this.d = 1;
        this.pc++;
        return { status: 'ok' };
      case '}':
        this.d = -1;
        this.pc--;
        return { status: 'ok' };
      case '[':
        if (this.d < 0 && (q = this.pair(this.pc, 1, '[', ']')) >= 0) {
          this.pc = q - 1;
          return { status: 'ok' };
        }
        break;
      case ']':
        if (this.d > 0 && (q = this.pair(this.pc, -1, ']', '[')) >= 0) {
          this.pc = q + 1;
          return { status: 'ok' };
        }
        break;
      case '~':
        this.pc = this.leaveLoop(this.pc, this.d);
        return { status: 'ok' };

      case '(':
      case ')':
        if (this.ret >= 0 && this.rs !== o) {
          q = this.ret;
          this.ret = -1;
          this.rs = '';
          this.pc = q;
          return { status: 'ok' };
        }
        this.ret = this.pc;
        this.rs = o;
        break;

      case '`': this.A = 0; break;

      default:
        return this.fail(`invalid character 0x${o.charCodeAt(0).toString(16).padStart(2, '0').toUpperCase()} at ${this.pc}`);
    }

    this.pc += this.d;
    return { status: 'ok' };
  }

  runSlice(limit = 20000) {
    let result = { status: 'ok' };
    for (let i = 0; i < limit; i++) {
      result = this.step();
      if (result.status !== 'ok') break;
    }
    this.onState(this.state());
    return result;
  }
}
