import { SymblicityVM } from './symblicity.js';

const $ = (sel) => document.querySelector(sel);
const source = $('#source');
const terminalEl = $('#terminal');
const statusEl = $('#status');
const exampleSel = $('#example');
const audioSel = $('#audio-set');
const soundFiles = $('#sound-files');
const runBtn = $('#run');
const stopBtn = $('#stop');
const stepBtn = $('#step');
const resetBtn = $('#reset');
const playBattleshipBtn = $('#play-battleship');
const fileInput = $('#program-file');
const stateEl = $('#state');
const audioStateEl = $('#audio-state');

class Terminal {
  constructor(el, cols = 120, rows = 52) {
    this.el = el;
    this.cols = cols;
    this.rows = rows;
    this.reset();
  }
  reset() {
    this.grid = Array.from({ length: this.rows }, () => Array.from({ length: this.cols }, () => null));
    this.row = 0; this.col = 0;
    this.fg = 'term-default'; this.bg = 'bg-default';
    this.esc = '';
    this.dirty = true;
    this.render();
  }
  clear() {
    this.grid = Array.from({ length: this.rows }, () => Array.from({ length: this.cols }, () => null));
    this.row = 0; this.col = 0; this.dirty = true;
  }
  scroll() {
    this.grid.shift();
    this.grid.push(Array.from({ length: this.cols }, () => null));
    this.row = this.rows - 1;
  }
  newline() {
    this.row++; this.col = 0;
    if (this.row >= this.rows) this.scroll();
  }
  sgr(params) {
    if (!params.length) params = [0];
    for (const p of params) {
      if (p === 0) { this.fg = 'term-default'; this.bg = 'bg-default'; }
      else if (p === 30) this.fg = 'term-black';
      else if (p === 31 || p === 91) this.fg = 'term-red';
      else if (p === 32 || p === 92) this.fg = 'term-green';
      else if (p === 33 || p === 93) this.fg = 'term-yellow';
      else if (p === 34 || p === 94) this.fg = 'term-blue';
      else if (p === 36 || p === 96) this.fg = 'term-cyan';
      else if (p === 37 || p === 97) this.fg = 'term-white';
      else if (p === 39) this.fg = 'term-default';
      else if (p === 40) this.bg = 'bg-black';
      else if (p === 41) this.bg = 'bg-red';
      else if (p === 43 || p === 103) this.bg = 'bg-yellow';
      else if (p === 49) this.bg = 'bg-default';
    }
  }
  ansi(seq) {
    if (!seq.startsWith('[')) return;
    const final = seq.at(-1);
    const body = seq.slice(1, -1);
    if (final === 'm') {
      const clean = body.replace(/^\?/, '');
      const params = clean === '' ? [0] : clean.split(';').map(x => Number.parseInt(x || '0', 10));
      this.sgr(params);
    } else if (final === 'H' || final === 'f') {
      const parts = body.split(';').map(x => Number.parseInt(x || '1', 10));
      this.row = Math.max(0, Math.min(this.rows - 1, (parts[0] || 1) - 1));
      this.col = Math.max(0, Math.min(this.cols - 1, (parts[1] || 1) - 1));
    } else if (final === 'J' && Number.parseInt(body || '0', 10) === 2) {
      this.clear();
    } else if ((final === 'h' || final === 'l') && body === '?1049') {
      if (final === 'h') this.clear();
    }
  }
  writeByte(b) {
    const ch = String.fromCharCode(b);
    if (this.esc) {
      this.esc += ch;
      if (/[A-Za-z]/.test(ch)) {
        this.ansi(this.esc);
        this.esc = '';
      } else if (this.esc.length > 32) this.esc = '';
      this.dirty = true;
      return;
    }
    if (b === 27) { this.esc = ''; this.esc = ''; this._escPending = true; return; }
    if (this._escPending) {
      this._escPending = false;
      this.esc = ch;
      return;
    }
    if (ch === '\n') { this.newline(); this.dirty = true; return; }
    if (ch === '\r') { this.col = 0; this.dirty = true; return; }
    if (ch === '\b') { this.col = Math.max(0, this.col - 1); this.dirty = true; return; }
    if (b < 32 && b !== 9) return;
    if (ch === '\t') {
      const spaces = 4 - (this.col % 4);
      for (let i = 0; i < spaces; i++) this.put(' ');
      return;
    }
    this.put(ch);
  }
  put(ch) {
    if (this.col >= this.cols) this.newline();
    this.grid[this.row][this.col] = { ch, fg: this.fg, bg: this.bg };
    this.col++;
    this.dirty = true;
  }
  writeNumber(n) {
    for (const c of String(n)) this.writeByte(c.charCodeAt(0));
  }
  render() {
    if (!this.dirty) return;
    const esc = (s) => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    let html = '';
    for (let r = 0; r < this.rows; r++) {
      let last = '', buf = '';
      const flush = () => {
        if (!buf) return;
        html += last ? `<span class="${last}">${esc(buf)}</span>` : esc(buf);
        buf = '';
      };
      let lastUsed = -1;
      for (let c = this.cols - 1; c >= 0; c--) if (this.grid[r][c]) { lastUsed = c; break; }
      const end = Math.max(lastUsed, 0);
      for (let c = 0; c <= end; c++) {
        const cell = this.grid[r][c] || { ch: ' ', fg: 'term-default', bg: 'bg-default' };
        const cls = `${cell.fg} ${cell.bg}`;
        if (cls !== last) { flush(); last = cls; }
        buf += cell.ch;
      }
      flush();
      if (r < this.rows - 1) html += '\n';
    }
    this.el.innerHTML = html;
    this.dirty = false;
  }
}

class BrowserAudio {
  constructor() {
    this.context = null;
    this.buffers = [];
    this.names = [];
    this.channels = [null, null];
    this.selected = 0;
    this.dual = true;
    this.loading = false;
    this.error = '';
  }
  get count() { return this.buffers.length; }
  async unlock() {
    if (!this.context) this.context = new (window.AudioContext || window.webkitAudioContext)();
    if (this.context.state === 'suspended') await this.context.resume();
  }
  stop(channel) {
    const src = this.channels[channel];
    if (src) {
      try { src.stop(); } catch {}
      try { src.disconnect(); } catch {}
      this.channels[channel] = null;
    }
    updateAudioState();
  }
  stopAll() { this.stop(0); this.stop(1); }
  play(channel, selected = this.selected) {
    if (!this.context || !this.buffers[selected]) return;
    this.stop(channel);
    const src = this.context.createBufferSource();
    src.buffer = this.buffers[selected];
    // The built-in background is the first sound and loops on channel 2.
    src.loop = selected === 0 && channel === 1 && this.names[0] === '00_background';
    const gain = this.context.createGain();
    gain.gain.value = selected === 0 && channel === 1 ? 0.55 : 0.9;
    src.connect(gain).connect(this.context.destination);
    src.onended = () => {
      if (this.channels[channel] === src) {
        this.channels[channel] = null;
        updateAudioState();
      }
    };
    this.channels[channel] = src;
    src.start();
    updateAudioState();
  }
  toneBuffer(freqs, seconds, shape = 'sine', volume = 0.45) {
    const rate = this.context.sampleRate;
    const buffer = this.context.createBuffer(1, Math.max(1, Math.floor(rate * seconds)), rate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      const t = i / rate;
      const attack = Math.min(1, t / 0.008);
      const release = Math.min(1, (seconds - t) / Math.min(0.08, seconds / 2));
      const env = Math.max(0, Math.min(attack, release));
      let sample = 0;
      for (let j = 0; j < freqs.length; j++) {
        const phase = 2 * Math.PI * freqs[j] * t;
        sample += shape === 'triangle' ? (2 / Math.PI) * Math.asin(Math.sin(phase)) : Math.sin(phase);
      }
      data[i] = volume * env * sample / freqs.length;
    }
    return buffer;
  }
  backgroundBuffer() {
    const rate = this.context.sampleRate;
    const seconds = 12;
    const buffer = this.context.createBuffer(1, rate * seconds, rate);
    const data = buffer.getChannelData(0);
    const chords = [
      [110.00, 164.81, 220.00],
      [98.00, 146.83, 196.00],
      [130.81, 196.00, 261.63],
      [87.31, 130.81, 174.61],
    ];
    for (let i = 0; i < data.length; i++) {
      const t = i / rate;
      const beat = Math.floor(t / 1.5) % chords.length;
      const chord = chords[beat];
      const local = t % 1.5;
      const env = 0.6 + 0.4 * Math.sin(Math.PI * Math.min(1, local / 1.5));
      let v = 0;
      for (const f of chord) v += Math.sin(2 * Math.PI * f * t) * 0.045;
      v += Math.sin(2 * Math.PI * (chord[0] / 2) * t) * 0.06;
      const pulse = Math.exp(-18 * (t % 0.375));
      v += (Math.sin(2 * Math.PI * 55 * t) + Math.sin(2 * Math.PI * 82.5 * t)) * 0.025 * pulse;
      data[i] = v * env;
    }
    return buffer;
  }
  async loadBuiltIn() {
    this.loading = true; this.error = ''; updateAudioState();
    try {
      await this.unlock();
      this.stopAll();
      this.names = ['00_background', '01_menu_nav', '02_menu_select', '03_hit', '04_sunk'];
      this.buffers = [
        this.backgroundBuffer(),
        this.toneBuffer([660, 880], 0.07, 'sine', 0.5),
        this.toneBuffer([440, 660, 880], 0.14, 'triangle', 0.45),
        this.toneBuffer([110, 73.42], 0.20, 'triangle', 0.65),
        this.toneBuffer([196, 146.83, 98], 0.52, 'triangle', 0.6),
      ];
      this.selected = 0;
    } catch (err) {
      this.error = err.message || String(err);
      this.buffers = []; this.names = [];
      throw err;
    } finally {
      this.loading = false; updateAudioState();
    }
  }
  async decode(name, data) {
    await this.unlock();
    const buffer = await this.context.decodeAudioData(data.slice(0));
    return { name, buffer };
  }
  async loadFiles(files) {
    this.loading = true; this.error = ''; updateAudioState();
    try {
      await this.unlock();
      const sorted = [...files].sort((a, b) => a.name.localeCompare(b.name));
      const decoded = [];
      for (const file of sorted) decoded.push(await this.decode(file.name, await file.arrayBuffer()));
      this.stopAll();
      this.names = decoded.map(x => x.name);
      this.buffers = decoded.map(x => x.buffer);
      this.selected = 0;
    } finally { this.loading = false; updateAudioState(); }
  }
  clear() { this.stopAll(); this.buffers = []; this.names = []; this.selected = 0; updateAudioState(); }
}

const terminal = new Terminal(terminalEl);
const audio = new BrowserAudio();
const vm = new SymblicityVM({
  audio,
  onByte: (b) => { terminal.writeByte(b); scheduleTerminalRender(); },
  onNumber: (n) => { terminal.writeNumber(n); scheduleTerminalRender(); },
  onAudio: (event) => {
    if (event.type === 'select') audio.selected = event.selected;
    else if (event.type === 'play') audio.play(event.channel, event.selected);
    else if (event.type === 'stop') audio.stop(event.channel);
    updateAudioState();
  },
  onState: updateState,
});

let running = false;
let waitTimer = null;
let renderPending = false;
let lastStateRender = 0;

function setStatus(text, kind = '') {
  statusEl.textContent = text;
  statusEl.dataset.kind = kind;
}

function updateState(state) {
  const now = performance.now();
  if (now - lastStateRender < 80 && running && !state.stopped && !state.error) return;
  lastStateRender = now;
  const regs = state.registers.map((v, i) => `R${i}=${String(v).padStart(3, ' ')}`).join('  ');
  stateEl.textContent = `${regs}   A=R${state.A} B=R${state.B}   PC=${state.pc}   ${state.direction > 0 ? '->' : '<-'}   stack=${state.stackSize}   steps=${state.steps}`;
  if (state.error) setStatus(`Error: ${state.error}`, 'error');
  else if (state.stopped && running) setStatus('Program finished', 'ok');
}

function updateAudioState() {
  if (audio.loading) { audioStateEl.textContent = 'Audio: loading...'; return; }
  if (audio.error) { audioStateEl.textContent = `Audio: ${audio.error}`; return; }
  if (!audio.count) { audioStateEl.textContent = 'Audio: disabled'; return; }
  const name = audio.names[audio.selected] || `#${audio.selected}`;
  audioStateEl.textContent = `Audio: ${audio.count} sounds | selected ${audio.selected}: ${name}`;
}

function scheduleTerminalRender() {
  if (renderPending) return;
  renderPending = true;
  requestAnimationFrame(() => { renderPending = false; terminal.render(); });
}

function cancelWaitTimer() {
  if (waitTimer !== null) clearTimeout(waitTimer);
  waitTimer = null;
}

function continueRun() {
  if (!running) return;
  cancelWaitTimer();
  const result = vm.runSlice(25000);
  scheduleTerminalRender();
  if (result.status === 'ok') {
    setTimeout(continueRun, 0);
  } else if (result.status === 'wait_char' || result.status === 'wait_number') {
    setStatus('Waiting for input -- click the terminal and type', 'wait');
    terminalEl.focus();
    // Match the native Battleship launcher without busy-waiting: one timeout
    // produces a zero byte, then the VM can decide whether it was standalone ESC.
    if (result.status === 'wait_char') {
      waitTimer = setTimeout(() => {
        waitTimer = null;
        if (!running || vm.waiting !== 'char') return;
        vm.queueBytes([0]);
        continueRun();
      }, 80);
    }
  } else {
    running = false;
    runBtn.disabled = false;
    stopBtn.disabled = true;
    if (result.status === 'stopped') setStatus('Program finished', 'ok');
  }
}

async function prepareAudioFromSelection() {
  if (audioSel.value === 'none') {
    audio.clear();
    return;
  }
  if (audioSel.value === 'battleship') {
    if (!audio.count || audio.names[0] !== '00_background') await audio.loadBuiltIn();
    return;
  }
  if (audioSel.value === 'local') {
    if (!soundFiles.files.length) throw new Error('Choose one or more local sound files first.');
    await audio.loadFiles(soundFiles.files);
  }
}

async function startProgram({ battleship = false } = {}) {
  try {
    stopProgram(false);
    await audio.unlock();
    if (battleship) {
      audioSel.value = 'battleship';
      await loadExample('battleship');
    }
    await prepareAudioFromSelection();
    audio.dual = true;
    terminal.reset();
    vm.reset(source.value);
    running = true;
    runBtn.disabled = true;
    stopBtn.disabled = false;
    setStatus('Running', 'ok');
    terminalEl.focus();
    continueRun();
  } catch (err) {
    running = false;
    setStatus(err.message || String(err), 'error');
  }
}

function stopProgram(show = true) {
  running = false;
  cancelWaitTimer();
  audio.stopAll();
  runBtn.disabled = false;
  stopBtn.disabled = true;
  if (show) setStatus('Stopped');
}

function resetProgram() {
  stopProgram(false);
  terminal.reset();
  vm.reset(source.value);
  setStatus('Reset');
}

async function loadExample(name) {
  if (name === 'hello') {
    source.value = '63"4320"38""@10"\\6438"\\"10"$"\\489"$50"';
    audioSel.value = 'none';
    audio.clear();
    setStatus('Loaded Hello World');
    return;
  }
  if (name === 'audio') {
    source.value = "VT'vt";
    audioSel.value = 'battleship';
    setStatus('Loaded dual-audio example');
    return;
  }
  if (name === 'battleship') {
    const res = await fetch('examples/battleship.sym');
    if (!res.ok) throw new Error('Could not load Battleship example.');
    source.value = await res.text();
    audioSel.value = 'battleship';
    setStatus('Loaded Battleship');
  }
}

function keyBytes(ev) {
  if (ev.key === 'ArrowUp') return [27, 91, 65];
  if (ev.key === 'ArrowDown') return [27, 91, 66];
  if (ev.key === 'ArrowRight') return [27, 91, 67];
  if (ev.key === 'ArrowLeft') return [27, 91, 68];
  if (ev.key === 'Escape') return [27];
  if (ev.key === 'Enter') return [13];
  if (ev.key === 'Backspace') return [8];
  if (ev.key.length === 1) {
    const bytes = new TextEncoder().encode(ev.key);
    return [...bytes];
  }
  return null;
}

terminalEl.addEventListener('keydown', (ev) => {
  if (!running) return;
  const bytes = keyBytes(ev);
  if (!bytes) return;
  ev.preventDefault();
  cancelWaitTimer();
  vm.queueBytes(bytes);
  continueRun();
});

runBtn.addEventListener('click', () => startProgram());
stopBtn.addEventListener('click', () => stopProgram());
resetBtn.addEventListener('click', resetProgram);
stepBtn.addEventListener('click', async () => {
  stopProgram(false);
  await audio.unlock();
  await prepareAudioFromSelection();
  if (vm.originalSource !== source.value || vm.stopped) { terminal.reset(); vm.reset(source.value); }
  const result = vm.step();
  updateState(vm.state()); scheduleTerminalRender();
  setStatus(result.status === 'ok' ? 'Stepped one instruction' : result.status);
});
playBattleshipBtn.addEventListener('click', () => startProgram({ battleship: true }));

exampleSel.addEventListener('change', async () => {
  if (!exampleSel.value) return;
  try { await loadExample(exampleSel.value); resetProgram(); } catch (err) { setStatus(err.message, 'error'); }
});
audioSel.addEventListener('change', () => {
  soundFiles.hidden = audioSel.value !== 'local';
  if (audioSel.value === 'none') audio.clear();
});
soundFiles.addEventListener('change', async () => {
  if (!soundFiles.files.length) return;
  try { await audio.loadFiles(soundFiles.files); setStatus(`Loaded ${audio.count} local sounds`, 'ok'); }
  catch (err) { setStatus(err.message || String(err), 'error'); }
});
fileInput.addEventListener('change', async () => {
  const file = fileInput.files[0];
  if (!file) return;
  source.value = await file.text();
  exampleSel.value = '';
  resetProgram();
  setStatus(`Loaded ${file.name}`, 'ok');
});

$('#download-source').addEventListener('click', () => {
  const blob = new Blob([source.value], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'program.sym'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
});

if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});

loadExample('hello').then(resetProgram);
updateAudioState();
